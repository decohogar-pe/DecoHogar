# 🏠 Deco Hogar — Guía de publicación en Vercel

## ¿Qué contiene este proyecto?
App web de venta de muebles de melamina con:
- Catálogo de productos
- Configurador de medidas
- Cotizador automático
- Carrito de compras
- Panel de administración

---

## PASO 1 — Crear cuenta en GitHub (gratis)
1. Ve a https://github.com
2. Haz clic en "Sign up"
3. Crea tu cuenta con tu email

---

## PASO 2 — Subir el proyecto a GitHub
1. En GitHub, haz clic en el botón verde "New" (repositorio nuevo)
2. Nómbralo: `deco-hogar`
3. Selecciona "Public" y haz clic en "Create repository"
4. Haz clic en "uploading an existing file"
5. **Arrastra TODA la carpeta** `deco-hogar` aquí
6. Haz clic en "Commit changes"

---

## PASO 3 — Publicar en Vercel (gratis)
1. Ve a https://vercel.com
2. Haz clic en "Sign Up" → elige "Continue with GitHub"
3. Haz clic en "Add New Project"
4. Selecciona el repositorio `deco-hogar`
5. Vercel detecta automáticamente que es React
6. Haz clic en **"Deploy"**
7. En 2 minutos tendrás tu link: `deco-hogar.vercel.app`

---

## PASO 4 — Compartir con tus clientes
Envía el link por WhatsApp. El cliente:
1. Abre el link en su celular
2. Toca el ícono de compartir (⬆) en iPhone o los 3 puntos en Android
3. Selecciona **"Agregar a pantalla de inicio"**
4. ¡Listo! La app aparece como ícono en su celular

---

## ✅ Resultado
- URL pública: `https://deco-hogar.vercel.app`
- Funciona en iPhone y Android
- Se instala como app sin Play Store
- Costo total: $0
